import React, { useState, useEffect } from 'react';

// Sayfalar
import TodoPage from './TodoPage';
import RoutinesPage from './RoutinesPage';
import BooksPage from './BooksPage';
import MoviesPage from './MoviesPage';

// İkonlar
import { Menu, X, LogOut, Check, Hourglass, BookOpen, Film } from 'lucide-react';

// Bu bileşen, onaylanmış kullanıcılar için ana uygulama arayüzünü oluşturur.
// Sol menü, ana içerik alanı ve sekmeler arası geçiş mantığını içerir.
const MainApp = ({ user, onLogout }) => {
    const [activeTab, setActiveTab] = useState('Yapılacaklar');
    const [isMenuOpen, setIsMenuOpen] = useState(true);
    const menuItems = ['Yapılacaklar', 'Rutinler', 'Kitaplar', 'Filmler'];

    // Ekran boyutuna göre menünün açık/kapalı durumunu ayarlar.
    useEffect(() => {
        const handleResize = () => setIsMenuOpen(window.innerWidth >= 1024);
        window.addEventListener('resize', handleResize);
        handleResize(); // İlk yüklemede de çalıştır
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    // Aktif sekmeye göre ilgili sayfa bileşenini render eder.
    const renderActivePage = () => {
        switch (activeTab) {
            case 'Yapılacaklar':
                return <TodoPage user={user} />;
            case 'Rutinler':
                return <RoutinesPage user={user} />;
            case 'Kitaplar':
                return <BooksPage user={user} />;
            case 'Filmler':
                return <MoviesPage user={user} />;
            default:
                return <TodoPage user={user} />;
        }
    };

    return (
        <div className="flex h-screen bg-gray-100 font-sans w-full">
            {/* Sol Menü */}
            <div className={`fixed inset-y-0 left-0 z-30 transform ${isMenuOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 lg:relative lg:translate-x-0`}>
                <nav className="w-64 h-full bg-white shadow-md flex flex-col">
                    <div className="p-6 flex justify-between items-center">
                        <h1 className="text-2xl font-bold text-blue-600">Görev Yöneticisi</h1>
                        <button onClick={() => setIsMenuOpen(false)} className="p-1 text-gray-500 lg:hidden"><X size={24} /></button>
                    </div>
                    <ul>
                        {menuItems.map(item => (
                            <li key={item} className="px-4 mb-2">
                                <button 
                                    onClick={() => { setActiveTab(item); if (window.innerWidth < 1024) setIsMenuOpen(false); }} 
                                    className={`w-full text-left px-4 py-3 rounded-lg font-semibold flex items-center gap-3 transition-colors ${activeTab === item ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-50'}`}
                                >
                                    {item === 'Yapılacaklar' && <Check size={20} />}
                                    {item === 'Rutinler' && <Hourglass size={20} />}
                                    {item === 'Kitaplar' && <BookOpen size={20} />}
                                    {item === 'Filmler' && <Film size={20} />}
                                    <span>{item}</span>
                                </button>
                            </li>
                        ))}
                    </ul>
                    <div className="mt-auto p-4">
                        <button 
                            onClick={onLogout} 
                            className="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-lg font-semibold text-red-600 bg-red-100 hover:bg-red-200 transition-colors"
                        >
                            <LogOut size={20} />
                            <span>Çıkış Yap</span>
                        </button>
                    </div>
                </nav>
            </div>

            {/* Ana İçerik Alanı */}
            <div className="flex-1 flex flex-col">
                <button 
                    onClick={() => setIsMenuOpen(true)} 
                    className={`fixed top-4 left-4 z-20 p-2 bg-white rounded-full shadow-md lg:hidden ${isMenuOpen ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
                >
                    <Menu size={20} />
                </button>
                <main className="flex-1 overflow-y-auto">
                    {renderActivePage()}
                </main>
            </div>
        </div>
    );
};

export default MainApp;
