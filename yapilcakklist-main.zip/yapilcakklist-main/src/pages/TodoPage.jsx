import React, { useState, useEffect } from 'react';

// Firebase ve Yapılandırma
import { db } from '../config/firebaseConfig';
import { 
    collection, 
    query, 
    onSnapshot, 
    addDoc, 
    updateDoc, 
    deleteDoc, 
    doc,
    writeBatch, // Toplu yazma işlemi için eklendi
    orderBy     // Sıralama için eklendi
} from "firebase/firestore";

// DND-Kit Kütüphaneleri
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragOverlay, useDroppable } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy, arrayMove } from '@dnd-kit/sortable';

// Bileşenler
import CalendarView from '../components/Todos/CalendarView';
import SortableTaskItem from '../components/Todos/SortableTaskItem';
import DraggedTaskOverlay from '../components/Todos/DraggedTaskOverlay';
import AddTaskModal from '../components/Todos/AddTaskModal';
import EditTaskModal from '../components/Todos/EditTaskModal';
import DayTasksModal from '../components/Todos/DayTasksModal';
import ColorPickerModal from '../components/Todos/ColorPickerModal';
import ConfirmDeleteModal from '../components/shared/ConfirmDeleteModal';

// İkonlar ve Yardımcılar
import { Plus } from 'lucide-react';
import { isToday, isPast, parseISO } from 'date-fns';
import { colorPalette } from '../config/constants';

// Butonları birer bırakma alanına dönüştüren yardımcı bileşen
const DroppableButton = ({ id, children, isOver }) => {
    const { setNodeRef } = useDroppable({ id });
    return (
        <div ref={setNodeRef} className={`transition-all duration-200 rounded-full ${isOver ? 'bg-blue-200 ring-2 ring-blue-500 scale-110' : ''}`}>
            {children}
        </div>
    );
}

const TodoPage = ({ user }) => {
    const [tasks, setTasks] = useState([]);
    const [calendarView, setCalendarView] = useState('weekly');
    const [currentDate, setCurrentDate] = useState(new Date());
    const [activeTaskView, setActiveTaskView] = useState('today');
    const [activeId, setActiveId] = useState(null);
    const [overId, setOverId] = useState(null);
    const [isModalOpen, setModalOpen] = useState({ add: false, delete: false, color: false, edit: false, day: false });
    const [modalPayload, setModalPayload] = useState({});

    // Mobil cihazlarda sürüklerken sayfa kaymasını engeller
    useEffect(() => {
        const preventScroll = (e) => { if (activeId) e.preventDefault(); };
        document.addEventListener('touchmove', preventScroll, { passive: false });
        return () => document.removeEventListener('touchmove', preventScroll);
    }, [activeId]);

    // Firestore'dan görevleri sıralı bir şekilde dinler
    useEffect(() => {
        if (!user) return;
        // DÜZELTME: Görevleri "order" alanına göre sıralı getir
        const q = query(collection(db, "users", user.uid, "tasks"), orderBy("order"));
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const tasksFromDb = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setTasks(tasksFromDb);
        });
        return () => unsubscribe();
    }, [user]);

    // Firestore İşlemleri
    const handleAddTask = async (content, status) => {
        // DÜZELTME: Yeni göreve bir "order" değeri ekle
        const newOrder = tasks.length > 0 ? Math.max(...tasks.map(t => t.order)) + 1 : 0;
        await addDoc(collection(db, "users", user.uid, "tasks"), { 
            content, 
            status, 
            color: colorPalette[Math.floor(Math.random() * colorPalette.length)], 
            isCompleted: false, 
            createdAt: new Date(),
            order: newOrder
        });
    };
    const confirmDelete = async () => { 
        await deleteDoc(doc(db, "users", user.uid, "tasks", modalPayload.id)); 
        closeModal('delete'); 
    };
    const handleSelectColor = async (taskId, color) => { 
        await updateDoc(doc(db, "users", user.uid, "tasks", taskId), { color }); 
        closeModal('color'); 
    };
    const handleEditTask = async (taskId, content) => { 
        await updateDoc(doc(db, "users", user.uid, "tasks", taskId), { content }); 
        closeModal('edit'); 
    };
    const toggleTaskCompletion = async (userId, taskId, isCompleted) => {
        await updateDoc(doc(db, "users", userId, "tasks", taskId), { isCompleted });
    };
    const handleTaskStatusChange = async (taskId, newStatus) => {
        await updateDoc(doc(db, "users", user.uid, "tasks", taskId), { status: newStatus });
    };

    // Modal Yönetimi
    const openModal = (type, payload = {}) => { setModalPayload(payload); setModalOpen(p => ({ ...p, [type]: true })); };
    const closeModal = (type) => setModalOpen(p => ({ ...p, [type]: false }));

    // Sürükle-Bırak Yönetimi
    const sensors = useSensors(useSensor(PointerSensor), useSensor(KeyboardSensor));
    const handleDragStart = (event) => setActiveId(event.active.id);
    const handleDragOver = (event) => setOverId(event.over ? event.over.id : null);
    const handleDragEnd = async (event) => {
        setActiveId(null); setOverId(null); const { active, over } = event; if (!over) return;
        if (over.id === 'planned-drop-area') { handleTaskStatusChange(active.id, 'planned'); return; }
        if (over.id === 'today-drop-area') { handleTaskStatusChange(active.id, 'today'); return; }
        if (active.id === over.id) return;
        
        const activeTask = tasks.find(t => t.id === active.id); 
        let overContainerId = over.data.current?.sortable?.containerId || over.id; 
        if (overContainerId.startsWith('placeholder-')) overContainerId = overContainerId.replace('placeholder-', '');
        
        if (activeTask.status !== overContainerId) { 
            handleTaskStatusChange(active.id, overContainerId); 
        } else { 
            const containerTasks = tasks.filter(t => t.status === activeTask.status); 
            const oldIndex = containerTasks.findIndex(t => t.id === active.id); 
            const newIndex = containerTasks.findIndex(t => t.id === over.id); 
            if (oldIndex !== -1 && newIndex !== -1) { 
                const newOrderedList = arrayMove(containerTasks, oldIndex, newIndex); 
                
                // DÜZELTME: Arayüzü anında güncelle ve Firestore'a kaydet
                const otherTasks = tasks.filter(t => t.status !== activeTask.status);
                setTasks([...otherTasks, ...newOrderedList]);

                const batch = writeBatch(db);
                newOrderedList.forEach((task, index) => {
                    const docRef = doc(db, "users", user.uid, "tasks", task.id);
                    batch.update(docRef, { order: index });
                });
                await batch.commit();
            } 
        }
    };
    const handleDragCancel = () => { setActiveId(null); setOverId(null); };

    // Görevleri filtreleme
    const todayTasks = tasks.filter(t => t.status === 'today' || (t.status.match(/^\d{4}-\d{2}-\d{2}$/) && isToday(parseISO(t.status))));
    const plannedTasks = tasks.filter(t => t.status === 'planned');
    const displayedTasks = activeTaskView === 'today' ? todayTasks : plannedTasks;
    const activeTask = activeId ? tasks.find(task => task.id === activeId) : null;

    return (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragStart={handleDragStart} onDragEnd={handleDragEnd} onDragOver={handleDragOver} onDragCancel={handleDragCancel}>
            <div className="p-4 sm:p-6 lg:p-8 space-y-8">
                <div className="bg-gray-50/70 rounded-xl p-4 flex flex-col h-full">
                    <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center space-x-2 p-1 bg-gray-200 rounded-full">
                            <DroppableButton id="today-drop-area" isOver={overId === 'today-drop-area'}><button onClick={() => setActiveTaskView('today')} className={`px-4 py-2 text-sm font-semibold rounded-full flex items-center gap-2 ${activeTaskView === 'today' ? 'bg-white text-blue-700 shadow-sm' : 'text-gray-600'}`}><span>☀️</span><span>Bugün</span></button></DroppableButton>
                            <DroppableButton id="planned-drop-area" isOver={overId === 'planned-drop-area'}><button onClick={() => setActiveTaskView('planned')} className={`px-4 py-2 text-sm font-semibold rounded-full flex items-center gap-2 ${activeTaskView === 'planned' ? 'bg-white text-blue-700 shadow-sm' : 'text-gray-600'}`}><span>⏳</span><span>Planlanan</span></button></DroppableButton>
                        </div>
                        <button onClick={() => openModal('add', { status: activeTaskView })} className="p-1 text-gray-500 hover:text-blue-600 rounded-full"><Plus className="h-6 w-6" /></button>
                    </div>
                    <SortableContext id={activeTaskView} items={displayedTasks.map(t => t.id)} strategy={verticalListSortingStrategy}><div className="flex-grow min-h-[250px] rounded-lg p-2 drop-zone">{displayedTasks.map((task, index) => <SortableTaskItem key={task.id} task={task} index={index} user={user} openDeleteModal={(id) => openModal('delete', { id })} openColorPicker={(task) => openModal('color', { task })} openEditModal={(task) => openModal('edit', { task })} toggleTaskCompletion={toggleTaskCompletion} />)}</div></SortableContext>
                </div>
                <CalendarView view={calendarView} tasks={tasks} currentDate={currentDate} setCurrentDate={setCurrentDate} onViewChange={setCalendarView} openAddTaskModal={(status) => openModal('add', { status })} openDayTasksModal={(dayKey, dayTasks) => openModal('day', { dayKey, dayTasks })} />
            </div>
            <DragOverlay>{activeTask ? <DraggedTaskOverlay task={activeTask} /> : null}</DragOverlay>
            <AddTaskModal isOpen={isModalOpen.add} onClose={() => closeModal('add')} onAddTask={handleAddTask} status={modalPayload.status} />
            <ConfirmDeleteModal isOpen={isModalOpen.delete} onClose={() => closeModal('delete')} onConfirm={confirmDelete} itemType="görevi" />
            <ColorPickerModal isOpen={isModalOpen.color} onClose={() => closeModal('color')} onSelectColor={handleSelectColor} task={modalPayload.task} />
            <EditTaskModal isOpen={isModalOpen.edit} onClose={() => closeModal('edit')} onEditTask={handleEditTask} task={modalPayload.task} />
            <DayTasksModal isOpen={isModalOpen.day} onClose={() => closeModal('day')} dayKey={modalPayload.dayKey} dayTasks={modalPayload.dayTasks} openDeleteModal={(id) => openModal('delete', { id })} openColorPicker={(task) => openModal('color', { task })} openEditModal={(task) => openModal('edit', { task })} toggleTaskCompletion={toggleTaskCompletion} user={user} />
        </DndContext>
    );
};

export default TodoPage;
