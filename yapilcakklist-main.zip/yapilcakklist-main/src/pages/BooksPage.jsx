import React, { useState, useEffect } from 'react';

// Firebase ve Yapılandırma
import { db } from '../config/firebaseConfig';
import { 
    collection, 
    query, 
    onSnapshot, 
    addDoc, 
    updateDoc, 
    deleteDoc, 
    doc 
} from "firebase/firestore";

// Bileşenler
import BookCard from '../components/Books/BookCard';
import AddBookModal from '../components/Books/AddBookModal';
import AddReadingSessionModal from '../components/Books/AddReadingSessionModal';
import ReadingCalendar from '../components/Books/ReadingCalendar';
import ConfirmDeleteModal from '../components/shared/ConfirmDeleteModal';

// İkonlar ve Yardımcılar
import { BookOpen, Plus } from 'lucide-react';
import { format } from 'date-fns';

const BooksPage = ({ user }) => {
    const [books, setBooks] = useState([]);
    const [isModalOpen, setModalOpen] = useState({ add: false, session: false, delete: false });
    const [modalPayload, setModalPayload] = useState({});

    // Firestore'dan kitapları anlık olarak dinler
    useEffect(() => {
        if (!user) return;
        const q = query(collection(db, "users", user.uid, "books"));
        const unsubscribe = onSnapshot(q, snapshot => {
            const booksFromDb = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setBooks(booksFromDb);
        });
        return () => unsubscribe();
    }, [user]);

    // Firestore İşlemleri
    const handleAddBook = async (bookData) => {
        await addDoc(collection(db, "users", user.uid, "books"), { 
            ...bookData, 
            readPages: [], 
            status: 'Okunuyor', 
            finishDate: null 
        });
        closeModal('add');
    };

    const handleAddReadingSession = async (bookId, date, pages) => {
        const bookRef = doc(db, "users", user.uid, "books", bookId);
        const book = books.find(b => b.id === bookId);
        const newReadPages = [...(book.readPages || []), { date, pages: parseInt(pages, 10) }];
        const totalRead = newReadPages.reduce((sum, s) => sum + s.pages, 0);
        const isFinished = totalRead >= book.totalPages;

        await updateDoc(bookRef, {
            readPages: newReadPages,
            status: isFinished ? 'Tamamlandı' : 'Okunuyor',
            finishDate: isFinished ? format(new Date(), 'yyyy-MM-dd') : null
        });
        closeModal('session');
    };

    const handleDeleteBook = async () => {
        await deleteDoc(doc(db, "users", user.uid, "books", modalPayload.id));
        closeModal('delete');
    };

    // Modal Yönetimi
    const openModal = (type, payload = {}) => { setModalPayload(payload); setModalOpen(p => ({ ...p, [type]: true })); };
    const closeModal = (type) => setModalOpen(p => ({ ...p, [type]: false }));

    return (
        <div className="p-4 sm:p-6 lg:p-8 space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                        <BookOpen className="h-6 w-6 text-blue-600" />
                        <h2 className="text-xl sm:text-2xl font-bold text-gray-700">Kitaplarım</h2>
                    </div>
                    <button 
                        onClick={() => openModal('add')} 
                        className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm flex items-center gap-2"
                    >
                        <Plus size={16} /> Yeni Kitap Ekle
                    </button>
                </div>
                {books.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {books.map(book => 
                            <BookCard 
                                key={book.id} 
                                book={book} 
                                onAddSession={() => openModal('session', { book })} 
                                onDelete={() => openModal('delete', { id: book.id })} 
                            />
                        )}
                    </div>
                ) : (
                    <p className="text-gray-500 text-center py-8">Henüz kitap eklenmemiş. Okumaya başlamak için yeni bir kitap ekleyin!</p>
                )}
            </div>
            
            <ReadingCalendar books={books} />

            {/* Modals */}
            <AddBookModal 
                isOpen={isModalOpen.add} 
                onClose={() => closeModal('add')} 
                onAddBook={handleAddBook} 
            />
            <AddReadingSessionModal 
                isOpen={isModalOpen.session} 
                onClose={() => closeModal('session')} 
                onAddReadingSession={handleAddReadingSession} 
                book={modalPayload.book} 
            />
            <ConfirmDeleteModal 
                isOpen={isModalOpen.delete} 
                onClose={() => closeModal('delete')} 
                onConfirm={handleDeleteBook} 
                itemType="kitabı" 
            />
        </div>
    );
};

export default BooksPage;
