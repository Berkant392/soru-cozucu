import React, { useState } from 'react';

// Firebase ve Yapılandırma
import { auth, db } from '../config/firebaseConfig';
import { 
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
} from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";

// Bileşenler
import FullScreenLoader from '../components/shared/FullScreenLoader';
import AlertDisplay from '../components/shared/AlertDisplay';
import LoginForm from '../components/Auth/LoginForm';
import SignupForm from '../components/Auth/SignupForm';

const AuthPage = () => {
    const [isLoginView, setIsLoginView] = useState(true);
    const [notification, setNotification] = useState({ message: "", type: "error" });
    const [loading, setLoading] = useState(false);

    // Firebase'den gelen hata kodlarını kullanıcı dostu mesajlara çevirir
    const getFriendlyErrorMessage = (errorCode) => {
        switch (errorCode) {
            case 'auth/user-not-found':
            case 'auth/wrong-password':
                return 'E-posta veya şifre hatalı.';
            case 'auth/invalid-email':
                return 'Geçersiz e-posta formatı.';
            case 'auth/email-already-in-use':
                return 'Bu e-posta adresi zaten kullanımda.';
            case 'auth/weak-password':
                return 'Şifre en az 6 karakter olmalıdır.';
            default:
                return 'Bir hata oluştu. Lütfen tekrar deneyin.';
        }
    };

    // Giriş yapma fonksiyonu
    const handleLogin = async (email, password) => {
        setLoading(true);
        setNotification({ message: "", type: "error" });
        try {
            await signInWithEmailAndPassword(auth, email, password);
            // Başarılı girişten sonra App.jsx'teki onAuthStateChanged yönlendirmeyi yapacak
        } catch (error) {
            setNotification({ message: getFriendlyErrorMessage(error.code), type: 'error' });
        } finally {
            setLoading(false);
        }
    };

    // Kayıt olma fonksiyonu
    const handleSignup = async (email, password, fullName) => {
        setLoading(true);
        setNotification({ message: "", type: "error" });
        try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            // Firestore'a yeni kullanıcı belgesi oluştur
            await setDoc(doc(db, "users", userCredential.user.uid), {
                fullName,
                email,
                createdAt: new Date(),
                isApproved: false // Yeni kullanıcılar varsayılan olarak onaylanmamış
            });
            // Başarılı kayıttan sonra App.jsx'teki onAuthStateChanged yönlendirmeyi yapacak
        } catch (error) {
            setNotification({ message: getFriendlyErrorMessage(error.code), type: 'error' });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="w-full max-w-md mx-auto bg-slate-900/60 backdrop-blur-md border border-blue-500/30 rounded-2xl shadow-2xl p-8">
            {loading && <FullScreenLoader />}
            <div className="text-center mb-8">
                <h1 className="text-4xl font-extrabold text-white">Hoş Geldiniz</h1>
                <p className="text-blue-300 mt-2">Görevlerinizi yönetmeye başlayın</p>
            </div>
            
            <AlertDisplay message={notification.message} type={notification.type} />

            {isLoginView ? (
                <LoginForm onSubmit={handleLogin} />
            ) : (
                <SignupForm onSubmit={handleSignup} />
            )}

            <div className="mt-6 text-center">
                <button 
                    onClick={() => setIsLoginView(!isLoginView)} 
                    className="text-sm font-medium text-blue-300 hover:text-white transition-colors"
                >
                    {isLoginView ? 'Hesabınız yok mu? Kayıt Olun' : 'Zaten bir hesabınız var mı? Giriş Yapın'}
                </button>
            </div>
        </div>
    );
};

export default AuthPage;
