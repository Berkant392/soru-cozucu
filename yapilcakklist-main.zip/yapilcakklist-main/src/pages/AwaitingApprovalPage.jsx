import React from 'react';
import { UserCheck } from 'lucide-react';

// Bu bileşen, hesabı henüz yönetici tarafından onaylanmamış
// kullanıcılar için bir bekleme ekranı gösterir.
const AwaitingApprovalPage = ({ onLogout }) => {
    return (
        <div className="w-full max-w-md mx-auto bg-slate-900/60 backdrop-blur-md border border-blue-500/30 rounded-2xl shadow-2xl p-8 text-center text-white">
            <UserCheck className="mx-auto h-16 w-16 text-blue-400 mb-4" />
            <h1 className="text-3xl font-extrabold">Onay Bekleniyor</h1>
            <p className="text-slate-300 mt-4">
                Hesabınız başarıyla oluşturuldu. Uygulamayı kullanabilmek için yöneticinin hesabınızı onaylaması gerekmektedir.
            </p>
            <p className="text-slate-400 mt-2 text-sm">
                Lütfen daha sonra tekrar deneyin veya yönetici ile iletişime geçin.
            </p>
            <button 
                onClick={onLogout} 
                className="w-full mt-8 py-3 px-4 rounded-md shadow-lg text-base font-medium text-white bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 transition-all duration-300 transform hover:scale-105"
            >
                Çıkış Yap
            </button>
        </div>
    );
};

export default AwaitingApprovalPage;
