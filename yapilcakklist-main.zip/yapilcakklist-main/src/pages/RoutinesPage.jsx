import React, { useState, useEffect } from 'react';

// Firebase ve Yapılandırma
import { db } from '../config/firebaseConfig';
import { 
    collection, 
    query, 
    onSnapshot, 
    addDoc, 
    updateDoc, 
    deleteDoc, 
    doc,
    writeBatch,
    orderBy,
    setDoc
} from "firebase/firestore";

// DND-Kit Kütüphaneleri
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy, arrayMove } from '@dnd-kit/sortable';

// Bileşenler
import CircularProgress from '../components/Routines/CircularProgress';
import RoutineDetailModal from '../components/Routines/RoutineDetailModal';
import AddRoutineModal from '../components/Routines/AddRoutineModal';
import EditRoutineModal from '../components/Routines/EditRoutineModal';
import SortableRoutineItem from '../components/Routines/SortableRoutineItem';
import ConfirmDeleteModal from '../components/shared/ConfirmDeleteModal';

// İkonlar ve Yardımcılar
import { Hourglass, Settings, Calendar, Plus, Pencil, Trash2, ChevronLeft, ChevronRight } from 'lucide-react';
import { format, addDays, startOfMonth, getDay, isToday, parseISO } from 'date-fns';
import { tr } from 'date-fns/locale';

const RoutinesPage = ({ user }) => {
    const [routines, setRoutines] = useState([]);
    const [completion, setCompletion] = useState({});
    const [currentDate, setCurrentDate] = useState(new Date());
    const [isModalOpen, setModalOpen] = useState({ add: false, detail: false, edit: false, delete: false });
    const [modalPayload, setModalPayload] = useState({});

    // Firestore'dan rutinleri sıralı bir şekilde dinler
    useEffect(() => {
        if (!user) return;
        const routinesQuery = query(collection(db, "users", user.uid, "routines"), orderBy("order"));
        const completionQuery = query(collection(db, "users", user.uid, "routine_completion"));
        
        const unsubRoutines = onSnapshot(routinesQuery, snapshot => setRoutines(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))));
        const unsubCompletion = onSnapshot(completionQuery, snapshot => {
            const completionData = {};
            snapshot.forEach(doc => { completionData[doc.id] = doc.data(); });
            setCompletion(completionData);
        });
        
        return () => { unsubRoutines(); unsubCompletion(); };
    }, [user]);

    // Firestore İşlemleri
    const handleAddRoutine = async (name) => { 
        await addDoc(collection(db, "users", user.uid, "routines"), { name, order: routines.length }); 
        closeModal('add'); 
    };
    const handleEditRoutine = async (id, name) => { await updateDoc(doc(db, "users", user.uid, "routines", id), { name }); closeModal('edit'); };
    const handleDeleteRoutine = async () => { await deleteDoc(doc(db, "users", user.uid, "routines", modalPayload.id)); closeModal('delete'); };
    const toggleRoutineCompletion = async (dateKey, routineId) => {
        const dayCompletionRef = doc(db, "users", user.uid, "routine_completion", dateKey);
        const currentStatus = completion[dateKey]?.[routineId] || false;
        await setDoc(dayCompletionRef, { [routineId]: !currentStatus }, { merge: true });
    };

    // Modal Yönetimi
    const openModal = (type, payload = {}) => { setModalPayload(payload); setModalOpen(p => ({ ...p, [type]: true })); };
    const closeModal = (type) => setModalOpen(p => ({ ...p, [type]: false }));

    // Sürükle-Bırak Yönetimi
    const sensors = useSensors(useSensor(PointerSensor), useSensor(KeyboardSensor));
    const handleDragEnd = async (event) => {
        const { active, over } = event;
        if (active.id !== over.id) {
            const oldIndex = routines.findIndex((r) => r.id === active.id);
            const newIndex = routines.findIndex((r) => r.id === over.id);
            const newOrderedRoutines = arrayMove(routines, oldIndex, newIndex);
            
            setRoutines(newOrderedRoutines);

            const batch = writeBatch(db);
            newOrderedRoutines.forEach((routine, index) => {
                const docRef = doc(db, "users", user.uid, "routines", routine.id);
                batch.update(docRef, { order: index });
            });
            await batch.commit();
        }
    };

    const calculateDailyProgress = (dateKey) => {
        const dayRoutines = completion[dateKey];
        if (!dayRoutines || routines.length === 0) return 0;
        const completedCount = routines.filter(r => dayRoutines[r.id]).length;
        return (completedCount / routines.length) * 100;
    };
    
    const getProgressColorClass = (percentage) => {
        if (percentage === 100) return 'bg-green-500'; 
        if (percentage >= 75) return 'bg-lime-500'; 
        if (percentage >= 50) return 'bg-yellow-500'; 
        if (percentage > 0) return 'bg-orange-500'; 
        return 'bg-red-500';
    };
    
    const changeDate = (amount) => {
        setCurrentDate(prevDate => new Date(prevDate.getFullYear(), prevDate.getMonth() + amount, 1));
    };

    const renderMonthlyCalendar = () => {
        const monthStart = startOfMonth(currentDate);
        const startDayOfWeek = getDay(monthStart) === 0 ? 6 : getDay(monthStart) - 1;
        const calendarStart = addDays(monthStart, -startDayOfWeek);
        return Array.from({ length: 42 }).map((_, i) => {
            const day = addDays(calendarStart, i);
            const dayKey = format(day, 'yyyy-MM-dd');
            const percentage = calculateDailyProgress(dayKey);
            const isCurrentMonth = day.getMonth() === currentDate.getMonth();
            const isCurrentDayToday = isToday(day);
            return (
                <div key={dayKey} className={`relative border-2 rounded-lg flex flex-col group cursor-pointer ${isCurrentMonth ? 'border-blue-300 bg-white' : 'border-gray-200 bg-gray-50/70'} ${isCurrentDayToday ? 'ring-2 ring-blue-500' : ''}`} onClick={() => openModal('detail', { dateKey: dayKey })}>
                    <span className={`text-xs font-semibold self-start m-2 ${isCurrentDayToday ? 'bg-blue-600 text-white rounded-full h-6 w-6 flex items-center justify-center' : ''}`}>{format(day, 'd')}</span>
                    <div className="flex-grow flex flex-col items-center justify-center text-center text-xs font-semibold">
                        {routines.length > 0 && isCurrentMonth && <>
                            <div className={`w-full h-2 rounded-full ${getProgressColorClass(percentage)}`}></div>
                            <span className="text-gray-700 mt-1">{Math.round(percentage)}%</span>
                        </>}
                    </div>
                </div>
            );
        });
    };
    
    return (
        <div className="p-4 sm:p-6 lg:p-8 space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
                <div className="flex items-center space-x-2 mb-4"><Hourglass className="h-6 w-6 text-blue-600" /><h2 className="text-xl sm:text-2xl font-bold text-gray-700">Rutinler ve İlerleme</h2></div>
                <div className="flex flex-col md:flex-row items-center justify-between bg-blue-50 rounded-lg p-4 mb-6 shadow-inner">
                    <div className="flex items-center space-x-4"><CircularProgress percentage={calculateDailyProgress(format(new Date(), 'yyyy-MM-dd'))} /><div><p className="text-lg font-semibold text-blue-800">Bugünün İlerlemesi</p><p className="text-sm text-blue-600">Günlük rutin tamamlama yüzdesi.</p></div></div>
                    <button onClick={() => openModal('add')} className="mt-4 md:mt-0 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 text-sm flex items-center gap-2"><Plus size={16} /> Yeni Rutin Ekle</button>
                </div>
                <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6 mb-6">
                    <div className="flex items-center space-x-2 mb-4"><Settings className="h-6 w-6 text-blue-600" /><h2 className="text-xl font-bold text-gray-700">Tanımlı Rutinler</h2></div>
                    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                        <SortableContext items={routines.map(r => r.id)} strategy={verticalListSortingStrategy}>
                            <div className="space-y-2">
                                {routines.length > 0 ? routines.map((routine, index) => (
                                    <SortableRoutineItem 
                                        key={routine.id} 
                                        id={routine.id} 
                                        routine={routine} 
                                        index={index} 
                                        onEdit={() => openModal('edit', { routine })} 
                                        onDelete={() => openModal('delete', { id: routine.id })}
                                    />
                                )) : <p className="text-gray-500 text-center py-4">Henüz rutin eklenmemiş.</p>}
                            </div>
                        </SortableContext>
                    </DndContext>
                </div>
                <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
                    <div className="flex justify-between items-center mb-4">
                        <div className="flex items-center space-x-2"><Calendar className="h-6 w-6 text-blue-600" /><h2 className="text-xl font-bold text-gray-700">Rutin Takvimi</h2></div>
                        <div className="flex items-center gap-4">
                            <button onClick={() => changeDate(-1)} className="p-2 rounded-full hover:bg-gray-100 transition-colors"><ChevronLeft size={20} /></button>
                            <h3 className="text-lg font-bold text-gray-800 w-32 text-center">{format(currentDate, 'MMMM yyyy', { locale: tr })}</h3>
                            <button onClick={() => changeDate(1)} className="p-2 rounded-full hover:bg-gray-100 transition-colors"><ChevronRight size={20} /></button>
                        </div>
                    </div>
                    <div className="grid grid-cols-7 gap-2" style={{ gridAutoRows: 'minmax(100px, auto)' }}>{renderMonthlyCalendar()}</div>
                </div>
            </div>
            {/* Modals for Routines */}
            <AddRoutineModal isOpen={isModalOpen.add} onClose={() => closeModal('add')} onAddRoutine={handleAddRoutine} />
            <EditRoutineModal isOpen={isModalOpen.edit} onClose={() => closeModal('edit')} onEditRoutine={handleEditRoutine} routine={modalPayload.routine} />
            <ConfirmDeleteModal isOpen={isModalOpen.delete} onClose={() => closeModal('delete')} onConfirm={handleDeleteRoutine} itemType="rutini" />
            <RoutineDetailModal 
                isOpen={isModalOpen.detail} 
                onClose={() => closeModal('detail')} 
                dateKey={modalPayload.dateKey} 
                routines={routines} 
                completion={completion[modalPayload.dateKey] || {}} 
                onToggle={toggleRoutineCompletion} 
            />
        </div>
    );
};

export default RoutinesPage;
