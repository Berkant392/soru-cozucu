import React, { useState, useEffect } from 'react';

// Firebase ve Yapılandırma
import { db } from '../config/firebaseConfig';
import { 
    collection, 
    query, 
    onSnapshot, 
    addDoc, 
    updateDoc, 
    deleteDoc, 
    doc 
} from "firebase/firestore";

// Bileşenler
import MovieCard from '../components/Movies/MovieCard';
import ConfirmDeleteModal from '../components/shared/ConfirmDeleteModal';

// İkonlar ve Yardımcılar
import { Film, Plus } from 'lucide-react';
import { format } from 'date-fns';

const MoviesPage = ({ user }) => {
    const [movies, setMovies] = useState([]);
    const [newMovieName, setNewMovieName] = useState('');
    const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
    const [movieToDeleteId, setMovieToDeleteId] = useState(null);

    // Firestore'dan filmleri anlık olarak dinler
    useEffect(() => {
        if (!user) return;
        const q = query(collection(db, "users", user.uid, "movies"));
        const unsubscribe = onSnapshot(q, snapshot => {
            const moviesFromDb = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setMovies(moviesFromDb);
        });
        return () => unsubscribe();
    }, [user]);

    // Firestore İşlemleri
    const handleAddMovie = async (e) => {
        e.preventDefault();
        if (newMovieName.trim()) {
            await addDoc(collection(db, "users", user.uid, "movies"), { 
                name: newMovieName.trim(), 
                watched: false, 
                addedDate: format(new Date(), 'yyyy-MM-dd') 
            });
            setNewMovieName('');
        }
    };

    const handleToggleWatched = async (id, currentStatus) => {
        await updateDoc(doc(db, "users", user.uid, "movies", id), { watched: !currentStatus });
    };

    const handleDeleteMovie = async () => {
        if (movieToDeleteId) {
            await deleteDoc(doc(db, "users", user.uid, "movies", movieToDeleteId));
            setDeleteModalOpen(false);
            setMovieToDeleteId(null);
        }
    };
    
    const openDeleteModal = (id) => {
        setMovieToDeleteId(id);
        setDeleteModalOpen(true);
    };

    return (
        <div className="p-4 sm:p-6 lg:p-8 space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
                <div className="flex items-center space-x-2 mb-4">
                    <Film className="h-6 w-6 text-blue-600" />
                    <h2 className="text-xl sm:text-2xl font-bold text-gray-700">Filmlerim</h2>
                </div>
                <form onSubmit={handleAddMovie} className="mb-6 flex flex-col sm:flex-row gap-4">
                    <input 
                        type="text" 
                        value={newMovieName} 
                        onChange={e => setNewMovieName(e.target.value)} 
                        placeholder="Film adı..." 
                        className="flex-grow p-2 border border-gray-300 rounded-md" 
                    />
                    <button 
                        type="submit" 
                        className="px-4 py-2 bg-blue-600 text-white rounded-md flex items-center justify-center gap-2 hover:bg-blue-700"
                    >
                        <Plus size={16} /> Listeye Ekle
                    </button>
                </form>
                {movies.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {movies.map(movie => 
                            <MovieCard 
                                key={movie.id} 
                                movie={movie} 
                                onToggleWatched={handleToggleWatched} 
                                onDelete={openDeleteModal} 
                            />
                        )}
                    </div>
                ) : (
                    <p className="text-gray-500 text-center py-8">Henüz film eklenmemiş. İzleme listenizi oluşturmaya başlayın!</p>
                )}
            </div>
            <ConfirmDeleteModal 
                isOpen={isDeleteModalOpen} 
                onClose={() => setDeleteModalOpen(false)} 
                onConfirm={handleDeleteMovie} 
                itemType="filmi" 
            />
        </div>
    );
};

export default MoviesPage;
