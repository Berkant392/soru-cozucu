import React, { useState } from 'react';
import { format } from 'date-fns';

// Bu bileşen, yeni bir kitap eklemek için kullanılan
// modal (pencere) formunu içerir.
const AddBookModal = ({ isOpen, onClose, onAddBook }) => {
    const [title, setTitle] = useState('');
    const [totalPages, setTotalPages] = useState('');
    const [startDate, setStartDate] = useState(format(new Date(), 'yyyy-MM-dd'));
    
    // Form gönderildiğinde, kitap bilgilerini ana bileşene (BooksPage) iletir.
    const handleSubmit = (e) => {
        e.preventDefault();
        if(title.trim() && totalPages > 0) {
            onAddBook({ title: title.trim(), totalPages: parseInt(totalPages), startDate });
            // Formu sıfırla
            setTitle('');
            setTotalPages('');
            setStartDate(format(new Date(), 'yyyy-MM-dd'));
            onClose(); // Modalı kapat
        }
    };

    // Modal açık değilse, hiçbir şey render etme.
    if (!isOpen) {
        return null;
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
                <h3 className="text-lg font-bold mb-4">Yeni Kitap Ekle</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <input 
                        type="text" 
                        value={title} 
                        onChange={e => setTitle(e.target.value)} 
                        placeholder="Kitap Adı" 
                        className="w-full p-2 border border-gray-300 rounded" 
                        required 
                    />
                    <input 
                        type="number" 
                        value={totalPages} 
                        onChange={e => setTotalPages(e.target.value)} 
                        placeholder="Toplam Sayfa Sayısı" 
                        className="w-full p-2 border border-gray-300 rounded" 
                        required 
                        min="1" 
                    />
                    <div>
                        <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">
                            Başlangıç Tarihi
                        </label>
                        <input 
                            type="date" 
                            id="startDate" 
                            value={startDate} 
                            onChange={e => setStartDate(e.target.value)} 
                            className="w-full p-2 border border-gray-300 rounded" 
                            required 
                        />
                    </div>
                    <div className="flex justify-end gap-2">
                        <button 
                            type="button" 
                            onClick={onClose} 
                            className="px-4 py-2 bg-gray-200 rounded"
                        >
                            İptal
                        </button>
                        <button 
                            type="submit" 
                            className="px-4 py-2 bg-blue-600 text-white rounded"
                        >
                            Ekle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddBookModal;
