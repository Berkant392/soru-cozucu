import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';

// Bu bileşen, bir kitaba yeni bir okuma oturumu (okunan sayfa sayısı)
// eklemek için kullanılan modal (pencere) formunu içerir.
const AddReadingSessionModal = ({ isOpen, onClose, onAddReadingSession, book }) => {
    const [pages, setPages] = useState('');

    // Modal her açıldığında input alanını temizle.
    useEffect(() => {
        if (isOpen) {
            setPages('');
        }
    }, [isOpen]);

    // Modal açık değilse veya kitap bilgisi yoksa, render etme.
    if (!isOpen || !book) {
        return null;
    }

    // Form gönderildiğinde, okunan sayfa sayısını ana bileşene (BooksPage) iletir.
    const handleSubmit = (e) => {
        e.preventDefault();
        if (pages > 0) {
            onAddReadingSession(book.id, format(new Date(), 'yyyy-MM-dd'), pages);
            onClose(); // Modalı kapat
        }
    };

    const totalReadSoFar = (book.readPages || []).reduce((sum, session) => sum + session.pages, 0);
    const remainingPages = book.totalPages - totalReadSoFar;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
                <h3 className="text-lg font-bold mb-2">Okuma Oturumu Ekle</h3>
                <p className="text-sm text-gray-600 mb-4">"{book.title}"</p>
                <p className="text-sm text-gray-500 mb-4">Kalan Sayfa: {remainingPages}</p>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <input 
                        type="number" 
                        value={pages} 
                        onChange={e => setPages(e.target.value)} 
                        placeholder="Okunan Sayfa Sayısı" 
                        className="w-full p-2 border border-gray-300 rounded" 
                        required 
                        min="1"
                        max={remainingPages} // Kullanıcının kalan sayfadan fazlasını girmesini engeller
                    />
                    <div className="flex justify-end gap-2">
                        <button 
                            type="button" 
                            onClick={onClose} 
                            className="px-4 py-2 bg-gray-200 rounded"
                        >
                            İptal
                        </button>
                        <button 
                            type="submit" 
                            className="px-4 py-2 bg-blue-600 text-white rounded"
                        >
                            Ekle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddReadingSessionModal;
