import React, { useState } from 'react';
import { format, addDays, startOfMonth, getDay, isToday } from 'date-fns';
import { tr } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { dayHeaderColors } from '../../config/constants';

// Bu bileşen, tüm kitaplardaki okuma oturumlarını toplayarak
// aylık bir takvim üzerinde hangi gün kaç sayfa okunduğunu gösterir.
const ReadingCalendar = ({ books }) => {
    const [currentDate, setCurrentDate] = useState(new Date());

    // Kitap verilerinden tarih bazında okunmuş sayfa sayısını hesaplar.
    const getPagesReadByDate = () => {
        const pagesByDate = {};
        books.forEach(book => {
            (book.readPages || []).forEach(session => {
                const dateKey = session.date;
                if (pagesByDate[dateKey]) {
                    pagesByDate[dateKey] += session.pages;
                } else {
                    pagesByDate[dateKey] = session.pages;
                }
            });
        });
        return pagesByDate;
    };

    const pagesReadByDate = getPagesReadByDate();
    
    // Takvimde ay değiştirme fonksiyonu
    const changeDate = (amount) => {
        setCurrentDate(prevDate => new Date(prevDate.getFullYear(), prevDate.getMonth() + amount, 1));
    };

    // Aylık takvim görünümünü oluşturan fonksiyon
    const renderMonth = () => {
        const monthStart = startOfMonth(currentDate);
        const startDayOfWeek = getDay(monthStart) === 0 ? 6 : getDay(monthStart) - 1; // Haftanın başlangıcı Pazartesi
        const calendarStart = addDays(monthStart, -startDayOfWeek);

        return Array.from({ length: 42 }).map((_, i) => {
            const day = addDays(calendarStart, i);
            const dayKey = format(day, 'yyyy-MM-dd');
            const pagesRead = pagesReadByDate[dayKey] || 0;
            const isCurrentMonth = day.getMonth() === currentDate.getMonth();
            const isCurrentDayToday = isToday(day);

            return (
                <div 
                    key={dayKey} 
                    className={`relative border-2 rounded-lg flex flex-col group p-2 transition-shadow duration-200 
                        ${isCurrentMonth ? 'border-blue-300 bg-white' : 'border-gray-200 bg-gray-50/70'} 
                        ${pagesRead > 0 ? 'hover:shadow-lg' : ''}`}
                >
                    <span className={`text-xs font-semibold self-start m-1 ${isCurrentDayToday ? 'bg-blue-600 text-white rounded-full h-6 w-6 flex items-center justify-center' : 'text-gray-700'}`}>
                        {format(day, 'd')}
                    </span>
                    <div className="flex-grow flex items-center justify-center text-center">
                        {pagesRead > 0 && (
                            <span className="text-sm font-bold text-blue-700">{pagesRead} Sayfa</span>
                        )}
                    </div>
                </div>
            );
        });
    };

    return (
        <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
            <div className="flex items-center justify-between mb-4">
                 <div className="flex items-center space-x-2">
                    <Calendar className="h-6 w-6 text-blue-600" />
                    <h2 className="text-xl font-bold text-gray-700">Okuma Takvimi</h2>
                 </div>
                 <div className="flex items-center gap-2">
                    <button onClick={() => changeDate(-1)} className="p-2 rounded-full hover:bg-gray-100">
                        <ChevronLeft size={20} />
                    </button>
                    <h3 className="text-lg font-bold text-gray-800">
                        {format(currentDate, 'MMMM yyyy', { locale: tr })}
                    </h3>
                    <button onClick={() => changeDate(1)} className="p-2 rounded-full hover:bg-gray-100">
                        <ChevronRight size={20} />
                    </button>
                 </div>
            </div>
            <div className="grid grid-cols-7 gap-2 mb-2">
                {['PZT', 'SAL', 'ÇAR', 'PER', 'CUM', 'CMT', 'PAZ'].map((day, index) => (
                    <div key={day} className={`py-2 text-center font-bold text-xs text-blue-800 ${dayHeaderColors[index]} rounded-lg shadow-sm`}>
                        {day}
                    </div>
                ))}
            </div>
            <div className="grid grid-cols-7 gap-2" style={{ gridAutoRows: 'minmax(100px, auto)' }}>
                {renderMonth()}
            </div>
        </div>
    );
};

export default ReadingCalendar;
