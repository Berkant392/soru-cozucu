import React from 'react';
import { format, parseISO } from 'date-fns';
import { tr } from 'date-fns/locale';
import { Plus, Trash2 } from 'lucide-react';

// Bu bileşen, tek bir kitap hakkındaki bilgileri gösteren bir kart oluşturur.
// Kitabın adı, sayfa ilerlemesi ve eylem butonları (okuma ekle, sil) burada yer alır.
const BookCard = ({ book, onAddSession, onDelete }) => {
    // Okunan toplam sayfa sayısını hesaplar.
    const totalReadPages = (book.readPages || []).reduce((sum, session) => sum + session.pages, 0);
    
    // Okuma ilerlemesini yüzde olarak hesaplar.
    const progressPercentage = Math.min(100, (totalReadPages / book.totalPages) * 100);

    return (
        <div className="bg-gray-50 rounded-lg shadow-md p-4 border border-gray-200 flex flex-col">
            <h3 className="text-lg font-bold text-gray-800 mb-2">{book.title}</h3>
            <p className="text-sm text-gray-600 mb-1">Toplam Sayfa: {book.totalPages}</p>
            
            {/* Başlangıç ve bitiş tarihlerini formatlayarak gösterir */}
            {book.startDate && (
                <p className="text-sm text-gray-600 mb-1">
                    Başlangıç: {format(parseISO(book.startDate), 'dd MMMM yyyy', { locale: tr })}
                </p>
            )}
            {book.finishDate && (
                <p className="text-sm text-green-700 font-semibold mb-2">
                    Bitiş: {format(parseISO(book.finishDate), 'dd MMMM yyyy', { locale: tr })}
                </p>
            )}

            {/* İlerleme çubuğu */}
            <div className="w-full bg-gray-200 rounded-full h-2.5 my-2">
                <div
                    className={`h-2.5 rounded-full ${progressPercentage === 100 ? 'bg-green-500' : 'bg-blue-500'}`}
                    style={{ width: `${progressPercentage}%` }}
                ></div>
            </div>
            <p className="text-sm text-gray-700 font-semibold mb-4">
                Okunan: {totalReadPages} / {book.totalPages} ({Math.round(progressPercentage)}%)
            </p>

            <div className="flex justify-between items-center mt-auto pt-2 border-t border-gray-100">
                {/* Kitabın durumunu gösteren etiket */}
                <span className={`text-xs font-semibold px-2 py-1 rounded-full ${book.status === 'Tamamlandı' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
                    {book.status}
                </span>
                <div className="flex space-x-2">
                    {/* Okuma oturumu ekleme butonu (kitap tamamlandıysa pasif) */}
                    <button
                        onClick={onAddSession}
                        className="p-1 rounded-full hover:bg-blue-100 text-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
                        title="Okuma Oturumu Ekle"
                        disabled={book.status === 'Tamamlandı'}
                    >
                        <Plus size={18} />
                    </button>
                    {/* Kitabı silme butonu */}
                    <button
                        onClick={onDelete}
                        className="p-1 rounded-full hover:bg-red-100 text-red-600"
                        title="Kitabı Sil"
                    >
                        <Trash2 size={18} />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default BookCard;
