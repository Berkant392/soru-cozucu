import React from 'react';
import { format, parseISO } from 'date-fns';
import { tr } from 'date-fns/locale';
import { Check, Trash2 } from 'lucide-react';

// Bu bileşen, tek bir film hakkındaki bilgileri gösteren bir kart oluşturur.
const MovieCard = ({ movie, onToggleWatched, onDelete }) => {
    return (
        <div className={`bg-gray-50 rounded-lg p-4 border border-gray-200 flex flex-col ${movie.watched ? 'opacity-70 border-green-400' : ''}`}>
            <h3 className={`text-lg font-bold text-gray-800 mb-2 ${movie.watched ? 'line-through text-gray-500' : ''}`}>
                {movie.name}
            </h3>
            <p className="text-sm text-gray-500 mb-4">
                Eklenme Tarihi: {format(parseISO(movie.addedDate), 'dd MMMM yyyy', { locale: tr })}
            </p>

            <div className="flex justify-between items-center mt-auto pt-2 border-t border-gray-100">
                {/* Filmin izlenme durumunu gösteren etiket */}
                <span className={`text-xs font-semibold px-2 py-1 rounded-full ${movie.watched ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
                    {movie.watched ? 'İzlendi' : 'İzlenmedi'}
                </span>
                <div className="flex space-x-2">
                    {/* İzlenme durumunu değiştirme butonu */}
                    <button 
                        onClick={() => onToggleWatched(movie.id, movie.watched)} 
                        className="p-1 rounded-full hover:bg-blue-100 text-blue-600"
                        title={movie.watched ? "İzlenmedi olarak işaretle" : "İzlendi olarak işaretle"}
                    >
                        <Check size={18} />
                    </button>
                    {/* Filmi silme butonu */}
                    <button 
                        onClick={() => onDelete(movie.id)} 
                        className="p-1 rounded-full hover:bg-red-100 text-red-600"
                        title="Filmi Sil"
                    >
                        <Trash2 size={18} />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default MovieCard;
