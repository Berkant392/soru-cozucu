import React, { useState } from 'react';
import AlertDisplay from '../shared/AlertDisplay';

// Bu bileşen, yeni kullanıcıların ad-soyad, e-posta ve şifre
// bilgileriyle uygulamaya kaydolmalarını sağlayan formu oluşturur.
const SignupForm = ({ onSubmit }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [fullName, setFullName] = useState('');
    const [error, setError] = useState('');

    // Form gönderildiğinde, şifrelerin eşleşip eşleşmediğini kontrol eder.
    // Eşleşiyorsa, bilgileri AuthPage'den gelen onSubmit fonksiyonuna gönderir.
    const handleSubmit = (e) => {
        e.preventDefault();
        if (password !== confirmPassword) {
            setError('Girilen şifreler uyuşmuyor.');
            return;
        }
        setError('');
        onSubmit(email, password, fullName);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <AlertDisplay message={error} type="error" />
            <input 
                id="fullName" 
                type="text" 
                placeholder="Ad Soyad" 
                value={fullName} 
                onChange={e => setFullName(e.target.value)} 
                required 
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-md text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500" 
            />
            <input 
                id="email" 
                type="email" 
                placeholder="E-posta Adresi" 
                value={email} 
                onChange={e => setEmail(e.target.value)} 
                required 
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-md text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500" 
            />
            <input 
                id="password" 
                type="password" 
                placeholder="Şifre (en az 6 karakter)" 
                value={password} 
                onChange={e => setPassword(e.target.value)} 
                required 
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-md text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500" 
            />
            <input 
                id="confirmPassword" 
                type="password" 
                placeholder="Şifre Tekrar" 
                value={confirmPassword} 
                onChange={e => setConfirmPassword(e.target.value)} 
                required 
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-md text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500" 
            />
            <button 
                type="submit" 
                className="w-full py-3 px-4 rounded-md shadow-lg text-base font-medium text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 transform hover:scale-105"
            >
                Hesap Oluştur
            </button>
        </form>
    );
};

export default SignupForm;
