import React, { useState } from 'react';

// Bu bileşen, kullanıcıların e-posta ve şifrelerini girerek
// uygulamaya giriş yapmalarını sağlayan formu oluşturur.
const LoginForm = ({ onSubmit }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    // Form gönderildiğinde, state'teki email ve password değerlerini
    // AuthPage'den gelen onSubmit fonksiyonuna gönderir.
    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(email, password);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <input 
                id="email" 
                type="email" 
                placeholder="E-posta Adresi" 
                value={email} 
                onChange={e => setEmail(e.target.value)} 
                required 
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-md text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500" 
            />
            <input 
                id="password" 
                type="password" 
                placeholder="Şifre" 
                value={password} 
                onChange={e => setPassword(e.target.value)} 
                required 
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-md text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500" 
            />
            <button 
                type="submit" 
                className="w-full py-3 px-4 rounded-md shadow-lg text-base font-medium text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 transform hover:scale-105"
            >
                Giriş Yap
            </button>
        </form>
    );
};

export default LoginForm;
