import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical, Pencil, Palette, Trash2, Check, XCircle } from 'lucide-react';

// Bu bileşen, sürüklenip bırakılabilen tek bir görev öğesini temsil eder.
const SortableTaskItem = ({ task, openDeleteModal, openColorPicker, openEditModal, toggleTaskCompletion, index, user }) => {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging,
    } = useSortable({ id: task.id });

    // Sürükleme sırasında öğenin stilini ayarlar.
    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.5 : 1,
    };

    return (
        <div 
            ref={setNodeRef} 
            {...attributes} 
            className={`relative group select-none p-3 mb-3 rounded-lg bg-white border-l-4 transition-shadow duration-200`} 
            // Düzeltme: İki ayrı style özelliği birleştirildi.
            style={{ ...style, borderLeftColor: task.color }}
        >
            <div className="flex items-center justify-between">
                <div className="p-2 flex-shrink-0 cursor-grab" {...listeners}>
                    <GripVertical className="h-5 w-5 text-gray-400" />
                </div>
                
                <span className="text-gray-500 text-sm mr-2 font-bold">{index + 1}.</span>
                
                <button 
                    onClick={(e) => { e.stopPropagation(); toggleTaskCompletion(user.uid, task.id, !task.isCompleted); }} 
                    className="p-1 mr-2 rounded-full hover:bg-gray-200 flex-shrink-0"
                >
                    {task.isCompleted ? <Check size={20} className="text-green-600" /> : <XCircle size={20} className="text-gray-400" />}
                </button>

                <p className={`text-gray-800 text-sm flex-grow ${task.isCompleted ? 'line-through text-gray-500' : ''}`}>
                    {task.content}
                </p>
            </div>

            <div className="absolute top-2 right-2 flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={(e) => { e.stopPropagation(); openEditModal(task); }} className="p-1 hover:bg-gray-200 rounded-full">
                    <Pencil className="h-4 w-4 text-gray-500" />
                </button>
                <button onClick={(e) => { e.stopPropagation(); openColorPicker(task); }} className="p-1 hover:bg-gray-200 rounded-full">
                    <Palette className="h-4 w-4 text-gray-500" />
                </button>
                <button onClick={(e) => { e.stopPropagation(); openDeleteModal(task.id); }} className="p-1 hover:bg-gray-200 rounded-full">
                    <Trash2 className="h-4 w-4 text-red-500" />
                </button>
            </div>
        </div>
    );
};

export default SortableTaskItem;
