import React from 'react';
import { format, parseISO } from 'date-fns';
import { tr } from 'date-fns/locale';
import { X, Pencil, Palette, Trash2, Check, XCircle } from 'lucide-react';

// Bu bileşen, takvimden bir gün seçildiğinde o güne ait görevleri
// listeleyen ve düzenleme, silme gibi işlemlere olanak tanıyan
// bir modal (pencere) oluşturur.
const DayTasksModal = ({ isOpen, onClose, dayKey, dayTasks, openDeleteModal, openColorPicker, openEditModal, toggleTaskCompletion, user }) => {
    // Modal açık değilse veya gösterilecek görev yoksa, render etme.
    if (!isOpen) {
        return null;
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold text-gray-800">
                        {dayKey ? format(parseISO(dayKey), 'd MMMM yyyy, EEEE', { locale: tr }) : ''} Görevleri
                    </h3>
                    <button onClick={onClose} className="p-1 hover:bg-gray-200 rounded-full">
                        <X size={20} />
                    </button>
                </div>
                <div className="space-y-3">
                    {dayTasks && dayTasks.length > 0 ? (
                        dayTasks.map(task => (
                            <div key={task.id} className="relative group p-3 rounded-lg bg-white border-l-4 shadow-sm" style={{ borderLeftColor: task.color }}>
                                <div className="flex items-center justify-between">
                                    <button
                                        onClick={() => toggleTaskCompletion(user.uid, task.id, !task.isCompleted)}
                                        className="p-1 mr-2 rounded-full hover:bg-gray-200 flex-shrink-0"
                                    >
                                        {task.isCompleted ? (
                                            <Check size={20} className="text-green-600" />
                                        ) : (
                                            <XCircle size={20} className="text-gray-400" />
                                        )}
                                    </button>
                                    <p className={`text-gray-800 text-sm flex-grow ${task.isCompleted ? 'line-through text-gray-500' : ''}`}>
                                        {task.content}
                                    </p>
                                </div>
                                <div className="absolute top-2 right-2 flex items-center space-x-1">
                                    <button onClick={() => openEditModal(task)} className="p-1 hover:bg-gray-200 rounded-full"><Pencil className="h-4 w-4 text-gray-500" /></button>
                                    <button onClick={() => openColorPicker(task)} className="p-1 hover:bg-gray-200 rounded-full"><Palette className="h-4 w-4 text-gray-500" /></button>
                                    <button onClick={() => openDeleteModal(task.id)} className="p-1 hover:bg-gray-200 rounded-full"><Trash2 className="h-4 w-4 text-red-500" /></button>
                                </div>
                            </div>
                        ))
                    ) : (
                        <p className="text-gray-500 text-center py-4 text-sm">Bu güne ait görev bulunmamaktadır.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default DayTasksModal;
