import React from 'react';

// Bu bileşen, bir görev öğesi sürüklendiğinde fare imlecinin altında
// görünen görsel bir katman (overlay) oluşturur.
// Takvimdeki kompakt görünüme benzer bir stil kullanır.
const DraggedTaskOverlay = ({ task }) => {
    // Eğer sürüklenecek bir görev yoksa, hiçbir şey render etme.
    if (!task) {
        return null;
    }

    // Görevin tamamlanma durumuna göre rengi belirle.
    const displayColor = task.isCompleted ? '#9B9B9B' : task.color;

    return (
        // Takvimdeki kompakt görev önizlemesine benzer bir stil kullanalım.
        <div
            className={`p-2 rounded text-sm shadow-xl flex items-center gap-2`}
            style={{
                backgroundColor: `${displayColor}33`, // Yarı saydam arka plan
                borderLeft: `4px solid ${displayColor}`, // Renkli sol kenarlık
                width: 'auto', // Genişlik içeriğe göre ayarlanacak
                maxWidth: '200px', // Genişliği sınırla (Daha da kısaltıldı)
                transform: 'scale(1.05)', // Hafifçe büyüt
                zIndex: 9999, // Diğer tüm öğelerin üzerinde olmasını sağla
            }}
        >
            <span className={`font-semibold truncate ${task.isCompleted ? 'line-through text-gray-500' : 'text-gray-800'}`}>
                {task.content}
            </span>
        </div>
    );
};

export default DraggedTaskOverlay;
