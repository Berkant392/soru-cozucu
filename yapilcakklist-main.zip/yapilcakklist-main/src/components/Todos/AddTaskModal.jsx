import React, { useState } from 'react';

// Bu bileşen, yeni bir görev eklemek için kullanılan modal (pencere) formunu içerir.
const AddTaskModal = ({ isOpen, onClose, onAddTask, status }) => {
    const [content, setContent] = useState('');

    // Modal açık değilse hiçbir şey render etme.
    if (!isOpen) {
        return null;
    }

    // Form gönderildiğinde, görev içeriğini ana bileşene (TodoPage) iletir.
    const handleSubmit = (e) => {
        e.preventDefault();
        if (content.trim()) {
            onAddTask(content, status);
            setContent(''); // Giriş alanını temizle
            onClose(); // Modalı kapat
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                <h3 className="text-lg font-bold mb-4">Yeni Görev Ekle</h3>
                <form onSubmit={handleSubmit}>
                    <input 
                        type="text" 
                        value={content} 
                        onChange={(e) => setContent(e.target.value)} 
                        placeholder="Görev içeriği..." 
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                        autoFocus 
                    />
                    <div className="mt-4 flex justify-end space-x-2">
                        <button 
                            type="button" 
                            onClick={onClose} 
                            className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors"
                        >
                            İptal
                        </button>
                        <button 
                            type="submit" 
                            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                        >
                            Ekle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddTaskModal;
