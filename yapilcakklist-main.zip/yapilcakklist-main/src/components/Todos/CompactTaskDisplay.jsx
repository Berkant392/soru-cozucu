import React from 'react';

// Bu bileşen, takvim içindeki görevlerin küçük ve kompakt
// bir görsel temsilini oluşturur.
const CompactTaskDisplay = ({ task, index }) => {
    const displayColor = task.isCompleted ? '#9B9B9B' : task.color;
    return (
        <div
            className={`p-1 rounded text-xs truncate shadow-sm flex items-center gap-1`}
            style={{ backgroundColor: `${displayColor}33`, borderLeft: `3px solid ${displayColor}` }}
        >
            <span className={`text-gray-600 font-bold ${task.isCompleted ? 'line-through' : ''}`}>
                {index + 1}.
            </span>
            <span className={`${task.isCompleted ? 'line-through text-gray-500' : ''}`}>
                {task.content}
            </span>
        </div>
    );
};

export default CompactTaskDisplay;
