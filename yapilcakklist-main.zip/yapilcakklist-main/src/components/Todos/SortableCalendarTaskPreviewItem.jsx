import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import CompactTaskDisplay from './CompactTaskDisplay'; // Bu bileşeni de oluşturacağız

// Bu bileşen, takvim içindeki küçük, sürüklenip bırakılabilen
// görev önizlemelerini temsil eder.
const SortableCalendarTaskPreviewItem = ({ task, index }) => {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging,
    } = useSortable({ id: task.id });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0 : 1,
        boxShadow: 'none',
    };

    // Eğer görev bir yer tutucu ise (görev olmayan boş günler için)
    // görünmez bir eleman oluşturur.
    if (task.isPlaceholder) {
        return (
            <div
                ref={setNodeRef}
                {...attributes}
                {...listeners}
                className="invisible h-full w-full"
                style={style}
            ></div>
        );
    }

    return (
        <div
            ref={setNodeRef}
            {...attributes}
            {...listeners}
            className={`p-1 rounded text-xs truncate transition-shadow cursor-grab`}
            style={style}
        >
            <CompactTaskDisplay task={task} index={index} />
        </div>
    );
};

export default SortableCalendarTaskPreviewItem;
