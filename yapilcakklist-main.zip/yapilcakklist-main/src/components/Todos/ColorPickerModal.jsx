import React from 'react';
import { X } from 'lucide-react';
import { colorPalette } from '../../config/constants';

// Bu bileşen, bir görevin rengini değiştirmek için bir renk paleti
// sunan bir modal (pencere) oluşturur.
const ColorPickerModal = ({ isOpen, onClose, onSelectColor, task }) => {
    // Modal açık değilse veya renk seçilecek bir görev yoksa, render etme.
    if (!isOpen || !task) {
        return null;
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[100] p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-xs">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-bold">Renk Seç</h3>
                    <button onClick={onClose} className="p-1 hover:bg-gray-200 rounded-full">
                        <X size={20} />
                    </button>
                </div>
                <div className="grid grid-cols-6 gap-2">
                    {colorPalette.map(color => (
                        <button
                            key={color}
                            onClick={() => onSelectColor(task.id, color)}
                            className="w-10 h-10 rounded-full transition-transform transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                            style={{ backgroundColor: color }}
                            aria-label={`Renk ${color} seç`}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ColorPickerModal;
