import React from 'react';
import { format, addDays, startOfWeek, getDay, isPast, isToday, parseISO } from 'date-fns';
import { tr } from 'date-fns/locale';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import SortableCalendarTaskPreviewItem from './SortableCalendarTaskPreviewItem';
import { dayHeaderColors } from '../../config/constants';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';

// Bu bileşen, görevleri haftalık veya aylık bir takvim görünümünde sergiler.
const CalendarView = ({ view, tasks, currentDate, setCurrentDate, onViewChange, openAddTaskModal, openDayTasksModal }) => {
    const weekStartsOn = 1; // Haftanın başlangıcı Pazartesi

    // Haftalık görünümü render eder
    const renderWeek = () => {
        return Array.from({ length: 7 }).map((_, i) => {
            const day = addDays(startOfWeek(currentDate, { weekStartsOn }), i);
            const dayKey = format(day, 'yyyy-MM-dd');
            const dayTasks = tasks.filter(t => t.status === dayKey);
            const itemsForSortableContext = dayTasks.length > 0 ? dayTasks.map(t => t.id) : [`placeholder-${dayKey}`];
            const isCurrentDayToday = isToday(day);
            const isDayPast = isPast(day) && !isCurrentDayToday;

            return (
                <div key={dayKey} className={`relative bg-white rounded-lg p-2 flex flex-col border-2 overflow-hidden cursor-pointer ${isDayPast ? 'border-gray-300 bg-gray-100 opacity-70' : 'border-blue-300 hover:shadow-lg'}`} onClick={() => openDayTasksModal(dayKey, dayTasks)}>
                    <div className={`flex items-center justify-between p-2 border-b ${isCurrentDayToday ? 'bg-blue-100 text-blue-800' : 'bg-gray-50'} rounded-t-md`}>
                        <span className="font-semibold text-xs">{format(day, 'EEE', { locale: tr })}</span>
                        <span className={`font-bold text-sm ${isCurrentDayToday ? 'bg-blue-600 text-white rounded-full h-6 w-6 flex items-center justify-center' : ''}`}>{format(day, 'd')}</span>
                    </div>
                    {isDayPast && <div className="absolute inset-0 flex items-center justify-center bg-gray-200/50 rounded-lg"><X size={48} className="text-red-500 opacity-70" /></div>}
                    <SortableContext id={dayKey} items={itemsForSortableContext} strategy={verticalListSortingStrategy}>
                        <div className="flex-grow p-2 space-y-2 min-h-[100px] drop-zone bg-gray-50/50">
                            {dayTasks.length > 0 ? dayTasks.map((task, index) => <SortableCalendarTaskPreviewItem key={task.id} task={task} index={index} />) : <SortableCalendarTaskPreviewItem task={{ id: `placeholder-${dayKey}`, isPlaceholder: true }} index={0} />}
                        </div>
                    </SortableContext>
                    <button onClick={(e) => { e.stopPropagation(); if (!isDayPast) openAddTaskModal(dayKey); }} className={`w-full text-center py-1 text-xs mt-auto ${isDayPast ? 'text-gray-400 cursor-not-allowed' : 'text-gray-500 hover:bg-blue-100'}`} disabled={isDayPast}>+ Ekle</button>
                </div>
            );
        });
    };

    // Aylık görünümü render eder
    const renderMonth = () => {
        const monthStart = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        const startDayOfWeek = getDay(monthStart) === 0 ? 6 : getDay(monthStart) - 1;
        const calendarStart = addDays(monthStart, -startDayOfWeek);
        return Array.from({ length: 42 }).map((_, i) => {
            const day = addDays(calendarStart, i);
            const dayKey = format(day, 'yyyy-MM-dd');
            const dayTasks = tasks.filter(t => t.status === dayKey);
            const itemsForSortableContext = dayTasks.length > 0 ? dayTasks.map(t => t.id) : [`placeholder-${dayKey}`];
            const isCurrentMonth = day.getMonth() === currentDate.getMonth();
            const isCurrentDayToday = isToday(day);
            const isDayPast = isPast(day) && !isCurrentDayToday;
            return (
                <div key={dayKey} className={`relative border-2 rounded-lg flex flex-col group ${isCurrentMonth ? 'border-blue-300 bg-white cursor-pointer hover:shadow-lg' : 'border-gray-100 bg-gray-50/50'} ${isDayPast && isCurrentMonth ? 'opacity-70 bg-gray-100' : ''}`} onClick={isCurrentMonth ? () => openDayTasksModal(dayKey, dayTasks) : undefined}>
                    {isCurrentMonth && <>
                        <span className={`text-xs font-semibold self-start m-2 ${isCurrentDayToday ? 'bg-blue-600 text-white rounded-full h-6 w-6 flex items-center justify-center' : ''}`}>{format(day, 'd')}</span>
                        {isDayPast && <div className="absolute inset-0 flex items-center justify-center bg-gray-200/50 rounded-lg"><X size={48} className="text-red-500 opacity-70" /></div>}
                        <SortableContext id={dayKey} items={itemsForSortableContext} strategy={verticalListSortingStrategy}>
                            <div className="flex-grow p-1 space-y-1 min-h-[80px] drop-zone">
                                {dayTasks.length > 0 ? dayTasks.map((task, index) => <SortableCalendarTaskPreviewItem key={task.id} task={task} index={index} />) : <SortableCalendarTaskPreviewItem task={{ id: `placeholder-${dayKey}`, isPlaceholder: true }} index={0} />}
                            </div>
                        </SortableContext>
                    </>}
                </div>
            );
        });
    };

    const changeDate = (amount) => setCurrentDate(view === 'weekly' ? addDays(currentDate, amount * 7) : new Date(currentDate.getFullYear(), currentDate.getMonth() + amount, 1));

    return (
        <div className="bg-white rounded-xl shadow-sm p-4 sm:p-6">
            <div className="flex justify-between items-center mb-4">
                <div className="flex items-center space-x-4">
                    <button onClick={() => changeDate(-1)} className="p-2 rounded-full hover:bg-gray-100"><ChevronLeft className="h-5 w-5 text-gray-600" /></button>
                    <h3 className="text-xl font-bold text-gray-800">{view === 'weekly' ? `${format(startOfWeek(currentDate, { weekStartsOn }), 'd MMMM', { locale: tr })} - ${format(addDays(startOfWeek(currentDate, { weekStartsOn }), 6), 'd MMMM yyyy', { locale: tr })}` : format(currentDate, 'MMMM yyyy', { locale: tr })}</h3>
                    <button onClick={() => changeDate(1)} className="p-2 rounded-full hover:bg-gray-100"><ChevronRight className="h-5 w-5 text-gray-600" /></button>
                </div>
                <div className="flex items-center space-x-2 p-1 bg-gray-200 rounded-full">
                    <button onClick={() => onViewChange('weekly')} className={`px-4 py-1 text-sm font-semibold rounded-full ${view === 'weekly' ? 'bg-white text-blue-700 shadow-sm' : 'text-gray-600'}`}>Haftalık</button>
                    <button onClick={() => onViewChange('monthly')} className={`px-4 py-1 text-sm font-semibold rounded-full ${view === 'monthly' ? 'bg-white text-blue-700 shadow-sm' : 'text-gray-600'}`}>Aylık</button>
                </div>
            </div>
            <div className="grid grid-cols-7 gap-2 mb-2">{['PZT', 'SAL', 'ÇAR', 'PER', 'CUM', 'CMT', 'PAZ'].map((d, i) => <div key={d} className={`py-2 text-center font-bold text-sm text-blue-800 ${dayHeaderColors[i]} rounded-lg shadow-sm`}>{d}</div>)}</div>
            {view === 'weekly' ? <div className="grid grid-cols-1 md:grid-cols-7 gap-4">{renderWeek()}</div> : <div className="grid grid-cols-7 gap-2" style={{ gridAutoRows: 'minmax(120px, auto)' }}>{renderMonth()}</div>}
        </div>
    );
};

export default CalendarView;
