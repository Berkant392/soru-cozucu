import React, { useState, useEffect } from 'react';

// Bu bileşen, var olan bir görevin metnini düzenlemek için
// kullanılan modal (pencere) formunu içerir.
const EditTaskModal = ({ isOpen, onClose, onEditTask, task }) => {
    const [content, setContent] = useState('');

    // task prop'u değiştiğinde (yani yeni bir görev düzenlenmek istendiğinde)
    // input alanının içeriğini günceller.
    useEffect(() => {
        if (task) {
            setContent(task.content);
        }
    }, [task]);

    // Modal açık değilse hiçbir şey render etme.
    if (!isOpen) {
        return null;
    }

    // Form gönderildiğinde, güncellenmiş görev içeriğini
    // ana bileşene (TodoPage) iletir.
    const handleSubmit = (e) => {
        e.preventDefault();
        if (content.trim() && task) {
            onEditTask(task.id, content);
            onClose(); // Modalı kapat
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[100] p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                <h3 className="text-lg font-bold mb-4">Görevi Düzenle</h3>
                <form onSubmit={handleSubmit}>
                    <input 
                        type="text" 
                        value={content} 
                        onChange={(e) => setContent(e.target.value)} 
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                        autoFocus 
                    />
                    <div className="mt-4 flex justify-end space-x-2">
                        <button 
                            type="button" 
                            onClick={onClose} 
                            className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors"
                        >
                            İptal
                        </button>
                        <button 
                            type="submit" 
                            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                        >
                            Kaydet
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default EditTaskModal;
