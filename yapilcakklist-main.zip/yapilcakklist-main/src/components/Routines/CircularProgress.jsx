import React from 'react';

// Bu bileşen, bir yüzde değerini alarak dairesel bir ilerleme
// çubuğu (progress bar) oluşturur. SVG ve CSS transisyonları
// kullanılarak pürüzsüz bir animasyon sağlanır.
const CircularProgress = ({ percentage }) => {
    const radius = 50; // Dairenin yarıçapı
    const circumference = 2 * Math.PI * radius; // Dairenin çevresi

    // Yüzdeye göre ilerleme çubuğunun ne kadarının dolu olacağını hesaplar.
    const strokeDashoffset = circumference - (percentage / 100) * circumference;

    return (
        <div className="relative w-24 h-24 sm:w-32 sm:h-32">
            <svg className="w-full h-full" viewBox="0 0 120 120">
                {/* Arka plan dairesi */}
                <circle
                    className="text-gray-300"
                    strokeWidth="10"
                    stroke="currentColor"
                    fill="transparent"
                    r={radius}
                    cx="60"
                    cy="60"
                />
                {/* İlerleme dairesi */}
                <circle
                    className="text-blue-500 transition-all duration-500 ease-in-out"
                    strokeWidth="10"
                    strokeDasharray={circumference}
                    strokeDashoffset={strokeDashoffset}
                    strokeLinecap="round"
                    stroke="currentColor"
                    fill="transparent"
                    r={radius}
                    cx="60"
                    cy="60"
                    transform="rotate(-90 60 60)" // Çubuğun üstten başlamasını sağlar
                />
            </svg>
            {/* Ortadaki yüzde metni */}
            <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-lg sm:text-xl font-bold text-blue-700">
                    {`${Math.round(percentage)}%`}
                </span>
            </div>
        </div>
    );
};

export default CircularProgress;
