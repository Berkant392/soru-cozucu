import React, { useState } from 'react';

// Bu bileşen, yeni bir rutin tanımı eklemek için kullanılan
// modal (pencere) formunu içerir.
const AddRoutineModal = ({ isOpen, onClose, onAddRoutine }) => {
    const [name, setName] = useState('');

    // Modal açık değilse, hiçbir şey render etme.
    if (!isOpen) {
        return null;
    }

    // Form gönderildiğinde, yeni rutin adını ana bileşene (RoutinesPage) iletir.
    const handleSubmit = (e) => {
        e.preventDefault();
        if (name.trim()) {
            onAddRoutine(name.trim());
            setName(''); // Input alanını temizle
            onClose();   // Modalı kapat
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
                <h3 className="text-lg font-bold mb-4">Yeni Rutin Ekle</h3>
                <form onSubmit={handleSubmit}>
                    <input 
                        type="text" 
                        value={name} 
                        onChange={e => setName(e.target.value)} 
                        placeholder="Rutin adı (örn: Sabah Egzersizi)" 
                        className="w-full p-2 border rounded" 
                        autoFocus 
                    />
                    <div className="mt-4 flex justify-end gap-2">
                        <button 
                            type="button" 
                            onClick={onClose} 
                            className="px-4 py-2 bg-gray-200 rounded"
                        >
                            İptal
                        </button>
                        <button 
                            type="submit" 
                            className="px-4 py-2 bg-blue-600 text-white rounded"
                        >
                            Ekle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddRoutineModal;
