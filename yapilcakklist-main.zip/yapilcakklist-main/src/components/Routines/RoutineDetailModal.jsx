import React from 'react';
import { format, parseISO } from 'date-fns';
import { tr } from 'date-fns/locale';
import { X, Check } from 'lucide-react';

// Bu bileşen, takvimden bir gün seçildiğinde o güne ait rutinleri
// ve tamamlama durumlarını gösteren bir modal (pencere) oluşturur.
const RoutineDetailModal = ({ isOpen, onClose, dateKey, routines, completion, onToggle }) => {
    // Modal açık değilse veya gösterilecek bir gün anahtarı yoksa, render etme.
    if (!isOpen || !dateKey) {
        return null;
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
                <h3 className="text-lg font-bold mb-4">
                    {format(parseISO(dateKey), 'd MMMM yyyy, EEEE', { locale: tr })}
                </h3>
                <ul className="space-y-2">
                    {routines.map(routine => (
                        <li key={routine.id} className="flex justify-between items-center p-2 bg-gray-100 rounded">
                            <span className={completion[routine.id] ? 'line-through text-gray-500' : ''}>
                                {routine.name}
                            </span>
                            <button 
                                onClick={() => onToggle(dateKey, routine.id)} 
                                className={`p-2 rounded-full transition-colors ${completion[routine.id] ? 'bg-green-200 hover:bg-green-300' : 'bg-red-200 hover:bg-red-300'}`}
                            >
                                {completion[routine.id] ? <Check className="text-green-700" size={20} /> : <X className="text-red-700" size={20} />}
                            </button>
                        </li>
                    ))}
                </ul>
                <div className="mt-4 text-right">
                    <button 
                        onClick={onClose} 
                        className="px-4 py-2 bg-blue-600 text-white rounded"
                    >
                        Kapat
                    </button>
                </div>
            </div>
        </div>
    );
};

export default RoutineDetailModal;
