import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical, Pencil, Trash2 } from 'lucide-react';

// Bu bileşen, sürüklenip bırakılabilen tek bir rutin öğesini temsil eder.
const SortableRoutineItem = ({ id, routine, index, onEdit, onDelete }) => {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging,
    } = useSortable({ id });

    // Sürükleme sırasında öğenin stilini ayarlar.
    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.5 : 1, // Sürüklenirken öğeyi yarı saydam yap
    };

    return (
        <div
            ref={setNodeRef}
            style={style}
            {...attributes}
            className="flex items-center justify-between bg-gray-50 p-3 rounded-lg border border-gray-200"
        >
            <div className="flex items-center gap-3">
                {/* Sürükleme tutamacı */}
                <div {...listeners} className="cursor-grab touch-none">
                    <GripVertical className="text-gray-400" />
                </div>
                {/* Sıra Numarası */}
                <span className="font-bold text-gray-500">{index + 1}.</span>
                {/* Rutin Adı */}
                <span className="font-medium text-gray-800">{routine.name}</span>
            </div>
            <div className="flex items-center gap-2">
                {/* Düzenleme Butonu */}
                <button onClick={onEdit} className="p-1 text-blue-600 hover:bg-blue-100 rounded-full">
                    <Pencil size={18} />
                </button>
                {/* Silme Butonu */}
                <button onClick={onDelete} className="p-1 text-red-600 hover:bg-red-100 rounded-full">
                    <Trash2 size={18} />
                </button>
            </div>
        </div>
    );
};

export default SortableRoutineItem;
