import React from 'react';

// Bu bileşen, kullanıcıya çeşitli durumlarda (hata, başarı vb.)
// görsel geri bildirimler sunmak için kullanılır.
const AlertDisplay = ({ message, type = 'error' }) => {
    // Eğer gösterilecek bir mesaj yoksa, bileşen hiçbir şey render etmez.
    if (!message) {
        return null;
    }

    // Mesajın türüne göre (error, success) farklı stil sınıfları uygular.
    const typeClasses = {
        error: "bg-red-500/20 border border-red-500/30 text-red-300",
        success: "bg-green-500/20 border border-green-500/30 text-green-300"
    };

    return (
        <div 
            className={`px-4 py-3 rounded-lg relative mb-4 text-center text-sm ${typeClasses[type]}`} 
            role="alert"
        >
            {message}
        </div>
    );
};

export default AlertDisplay;
