import React from 'react';

// Bu bileşen, ekranın altından yukarı doğru yükselen, rastgele boyut ve
// hızlara sahip baloncuk animasyonları oluşturur. Genellikle estetik
// bir arka plan öğesi olarak kullanılır.
const AnimatedBubbles = () => {
    return (
        <div className="fixed inset-0 w-full h-full overflow-hidden z-0">
            {/* 10 adet baloncuk oluşturur */}
            {Array.from({ length: 10 }).map((_, i) => (
                <div 
                    key={i} 
                    className="absolute bg-white/10 rounded-full animate-bubble-rise" 
                    style={{
                        // Rastgele boyut, konum ve animasyon süresi atar
                        width: `${Math.random() * 60 + 20}px`,
                        height: `${Math.random() * 60 + 20}px`,
                        left: `${Math.random() * 100}%`,
                        animationDuration: `${Math.random() * 15 + 10}s`,
                        animationDelay: `${Math.random() * 5}s`,
                    }}
                ></div>
            ))}
        </div>
    );
};

export default AnimatedBubbles;
