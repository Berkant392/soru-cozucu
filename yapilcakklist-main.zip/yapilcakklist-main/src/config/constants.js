// Bu dosya, uygulama genelinde kullanılacak sabit değerleri içerir.
// Renk paletleri, ayar değerleri gibi verileri burada merkezileştirmek,
// kodun bakımını ve tutarlılığını kolaylaştırır.

export const colorPalette = [
    '#4A90E2', '#50E3C2', '#F5A623', '#BD10E0', '#D0021B', '#9B9B9B',
    '#7ED321', '#F8E71C', '#B8E986', '#417505', '#E91E63', '#9C27B0',
    '#3F51B5', '#00BCD4', '#009688', '#8BC34A', '#FFC107', '#FF5722'
];

export const dayHeaderColors = [
    'bg-blue-200', 
    'bg-teal-200', 
    'bg-purple-200', 
    'bg-yellow-200', 
    'bg-pink-200', 
    'bg-green-200', 
    'bg-red-200'
];
