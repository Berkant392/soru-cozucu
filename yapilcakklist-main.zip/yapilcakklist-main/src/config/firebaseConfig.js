// Firebase SDK'larından gerekli fonksiyonları içe aktar
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Vite ortam değişkenlerini kullanarak Firebase yapılandırma bilgilerini al
// Bu bilgiler Netlify arayüzünde tanımlanacak ve güvende tutulacak
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

// Firebase uygulamasını başlat
const app = initializeApp(firebaseConfig);

// Firebase servislerini (Authentication ve Firestore) başlat ve dışa aktar
export const auth = getAuth(app);
export const db = getFirestore(app);
