import React, { useState, useEffect } from 'react';

// Firebase ve Yapılandırma
import { auth, db } from './config/firebaseConfig';
import { onAuthStateChanged, signOut } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";

// Sayfalar
import AuthPage from './pages/AuthPage';
import AwaitingApprovalPage from './pages/AwaitingApprovalPage';
import MainApp from './pages/MainApp'; // MainApp'i bir sayfa olarak ele alıyoruz

// Paylaşılan Bileşenler
import FullScreenLoader from './components/shared/FullScreenLoader';
import AnimatedBubbles from './components/shared/AnimatedBubbles';

export default function App() {
    const [authState, setAuthState] = useState({ status: 'loading', user: null });

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
            if (user) {
                try {
                    const userDocRef = doc(db, "users", user.uid);
                    const userDoc = await getDoc(userDocRef);
                    
                    if (userDoc.exists() && userDoc.data().isApproved) {
                        setAuthState({ status: 'approved', user: user });
                    } else {
                        setAuthState({ status: 'unapproved', user: user });
                    }
                } catch (error) {
                    console.error("Kullanıcı durumu alınırken hata:", error);
                    setAuthState({ status: 'loggedOut', user: null });
                }
            } else {
                setAuthState({ status: 'loggedOut', user: null });
            }
        });
        return () => unsubscribe();
    }, []);

    const handleLogout = () => {
        signOut(auth).catch(error => console.error("Çıkış hatası:", error));
    };

    const renderContent = () => {
        switch (authState.status) {
            case 'loading':
                return <FullScreenLoader />;
            case 'approved':
                return <MainApp user={authState.user} onLogout={handleLogout} />;
            case 'unapproved':
                return <AwaitingApprovalPage onLogout={handleLogout} />;
            case 'loggedOut':
            default:
                return <AuthPage />;
        }
    };

    return (
        <div className={`min-h-screen w-full flex items-center justify-center p-4 transition-colors duration-500 ${authState.status === 'approved' ? 'bg-gray-100' : 'animated-gradient'}`}>
            {authState.status !== 'approved' && <AnimatedBubbles />}
            <div className="relative z-10 w-full h-full flex items-center justify-center">
                {renderContent()}
            </div>
            <style>{`
                .animated-gradient { background: linear-gradient(-45deg, #1e3a8a, #3b82f6, #4f46e5, #1d4ed8); background-size: 400% 400%; animation: gradient-move 15s ease infinite; }
                @keyframes gradient-move { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
                @keyframes bubble-rise { 0% { transform: translateY(0) scale(0.5); opacity: 0; } 10% { opacity: 1; } 100% { transform: translateY(-120vh) scale(1.2) rotate(360deg); opacity: 0; } }
                .animate-bubble-rise { animation-name: bubble-rise; animation-timing-function: linear; animation-iteration-count: infinite; }
                body {
                    -webkit-user-select: none; /* Safari */
                    -moz-user-select: none; /* Firefox */
                    -ms-user-select: none; /* IE10+/Edge */
                    user-select: none; /* Standard */
                }
                input, textarea {
                    -webkit-user-select: auto;
                    -moz-user-select: auto;
                    -ms-user-select: auto;
                    user-select: auto;
                }
            `}</style>
        </div>
    );
}
